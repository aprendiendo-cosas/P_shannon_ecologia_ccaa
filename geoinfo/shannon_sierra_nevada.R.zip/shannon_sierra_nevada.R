setwd("/Users/fjbonet/SynologyDrive/Drive/4_docencia/eco_ccaa_uco/actos_docentes/P_shannon_ecologia_ccaa/preparacion/2025_2026/")

presencias <- read.csv("0118822-200613084148143.csv", header = TRUE, sep = ",", dec = ".")

# sf: Para trabajar con datos vectoriales (puntos, polígonos)
install.packages("sf")
library(sf)

# terra: Para trabajar con datos raster (mapas en formato cuadrícula)
install.packages("terra")
library(terra)

# sqldf: Para manipular tablas como si fueran bases de datos
install.packages("sqldf")
library(sqldf)



# ¿Cuántos registros de presencia tenemos?
# la función nrow() cuenta el número de filas de un data frame (tabla)
nrow(presencias)

# Ver nombres de todas las columnas disponibles
# la función names() devuelve los nombres de las columnas de un data frame
names(presencias)

# Ver las primeras 6 filas para entender la estructura
# la función head() muestra las primeras filas de un data frame
head(presencias)

# ¿Cuántas especies diferentes aparecen?
# la función length() cuenta el número de elementos en un vector (que puede ser una tabla o una columna)
# la función unique() devuelve los valores únicos de un vector. En este caso de la columna scientificName
length(unique(presencias$scientificName))

# ¿Cuántos registros hay de cada especie?
table(presencias$scientificName)

# Generar histograma de abundancias de especies ordenadas de mayor a menor abundancia en el eje x

# la función table() cuenta las ocurrencias de cada valor en un vector
abundancias <- table(presencias$scientificName)

# ordenar las abundancias de mayor a menor usando la función sort()
abundancias_ordenadas <- sort(abundancias, decreasing = TRUE)

# Genera una gráfica de barras mostrando las abundancias de especies ordenadas de mayor a menor abundancia en el eje x.
barplot(abundancias_ordenadas,
        las = 2,               # Rota los nombres de las especies para que se vean mejor
        col = "lightblue",     # Color de las barras
        main = "Abundancia de especies registradas", # Título del gráfico
        ylab = "Número de registros",                # Etiqueta del eje y
        xlab = "Especies")                           # Etiqueta del eje x

# Convertir las coordenadas UTM en un objeto espacial. Usamos la función st_as_sf() del paquete sf que significa "simple features"

presencias_23030 <- st_as_sf(presencias, coords = c("UTM_X", "UTM_Y"),crs = 23030)

# Hacer un mapa sencillo para ver si tiene sentido geográficamente
plot(st_geometry(presencias_23030), 
     pch = 20,                  # Tipo de símbolo (puntos pequeños)
     cex = 0.1,                 # Tamaño de puntos
     col = "darkgreen",         # Color
     main = "Presencias de especies en Sierra Nevada")

# Bloque 3 Importación del mapa de comunidades ecológicas

comunidades<-st_read("vegetacion_snevada_23030.shp")

# Bloque 4 Hacemos unión espacial. Asigna a cada punto el código de la comunidad en la que se encuentra.

presencias_x_comunidades <- st_join(
  presencias_23030,  # Puntos (presencias_23030)
  comunidades,           # Polígonos (comunidades_23030)
  left = FALSE           # Eliminar puntos que no caen en ningún polígono
)

# Convertimos el objeto espacial sf a una tabla "normal"(dataframe)
bio <- as.data.frame(presencias_x_comunidades)

# Quedarnos SOLO con las dos columnas que necesitamos:
# - OBJECTID: identifica el polígono (comunidad)
# - scientificName: identifica la especie
bio <- bio[c('OBJECTID', 'scientificName')]


# Bloque 5. Hacemos cálculos de agrupación para obtener el índice de Shannon

# Contar el número de individuos por especie en cada comunidad (numerador de la abundancia relativa)
T_num_ind_sp_com <- sqldf("
  SELECT 
    OBJECTID,                          -- ID del polígono (comunidad)
    scientificName,                    -- Nombre de la especie
    count(scientificName) AS num_ind_sp_com  -- Contar individuos
  FROM bio 
  GROUP BY OBJECTID, scientificName    -- Agrupar por comunidad y especie
")

# Visualizamos los 10 primeros registros de la tabla creada
head(T_num_ind_sp_com, 10)

# Contar el número total de individuos en cada comunidad (denominador de la abundancia relativa)
# Sumamos el número total de individuos que hay en cada comunidad (Denominador de la abundancia relativa)
T_num_ind_com <- sqldf("
  SELECT 
    OBJECTID, 
    sum(num_ind_sp_com) AS num_ind_com   -- Sumar todos los individuos
  FROM T_num_ind_sp_com 
  GROUP BY OBJECTID                      -- Agrupar solo por comunidad
")

# Visualizamos los 10 primeros registros de la tabla creada
head(T_num_ind_com, 10)

# Unimos las tablas T_num_ind_com (denominador) y T_num_ind_sp_com (numerador)
T_num_ind_sp_com_mas_num_ind_com <- sqldf("
  SELECT 
    OBJECTID, 
    scientificName, 
    num_ind_sp_com,           -- De la tabla T_num_ind_sp_com
    num_ind_com               -- De la tabla T_num_ind_com
  FROM T_num_ind_sp_com 
  LEFT JOIN T_num_ind_com USING(OBJECTID)  -- Unir por OBJECTID
")

# Comprobamos los 10 primeros registros de la tabla generada
head(T_num_ind_sp_com_mas_num_ind_com, 10)

# Calculamos la abundancia relativa de cada especie sin usar el paquete sqldf
T_num_ind_sp_com_mas_num_ind_com$pi <- 
  T_num_ind_sp_com_mas_num_ind_com$num_ind_sp_com / 
  T_num_ind_sp_com_mas_num_ind_com$num_ind_com


# Calculamos el logaritmo en base 2 de la abundancia relativa
T_num_ind_sp_com_mas_num_ind_com$log2pi <- 
  log2(T_num_ind_sp_com_mas_num_ind_com$pi)

# Calculamos el término Pi * log2(Pi)
T_num_ind_sp_com_mas_num_ind_com$pi_log2pi <- 
  T_num_ind_sp_com_mas_num_ind_com$pi * 
  T_num_ind_sp_com_mas_num_ind_com$log2pi

# Bloque 6. Cálculo del índice de Shannon H por comunidad
# Calculamos el índice de Shannon H por comunidad sumando los términos Pi * log2(Pi) y multiplicando por -1
T_Shannon <- sqldf("
  SELECT 
    OBJECTID, 
    sum(pi_log2_pi) * -1 AS H   -- Índice de Shannon
  FROM T_num_ind_sp_com_mas_num_ind_com
  GROUP BY OBJECTID              -- Agrupar por comunidad
")

#Verificamos la existencia y contenido de la tabla creada
head(T_Shannon, 10)

# Bloque 7. Integración de resultados numéricos con el mapa de comunidades y exportación a formato SIG

# Unimos la tabla T_Shannon con la capa vectorial de comunidades
comunidades <- merge(
  x = comunidades,           # Capa espacial (polígonos)
  y = T_Shannon,             # Tabla con índice H
  by.x = "OBJECTID",         # Campo de unión en comunidades
  by.y = "OBJECTID"          # Campo de unión en T_Shannon
)

# Mostramos los 10 primeros registros de la tabla de atributos de comunidades para verificar que el índice H se ha añadido correctamente
head(comunidades, 10)

# Exportamos la capa de comunidades con el índice de Shannon a un archivo shapefile para visualizar en QGIS
st_write(comunidades, "Shannon_sierra_nevada.shp", append=FALSE)

# Exportamos a formato raster con resolución de 100 metros
# Primero, creamos una plantilla raster con la extensión y resolución deseada
plantilla_raster <- rast(comunidades, 
  resolution = 100, 
  crs = st_crs(comunidades)$proj4string) 

# Creamos un archivo Tiff para el índice de Shannon
shannon_raster <- rasterize(
  comunidades,               # Capa vectorial con el índice H
  plantilla_raster,         # Plantilla raster
  field = "H"               # Campo que contiene el índice de Shannon
)
# Guardamos el raster en un archivo GeoTIFF
writeRaster(shannon_raster, "Shannon_sierra_nevada.tif", overwrite=TRUE)
